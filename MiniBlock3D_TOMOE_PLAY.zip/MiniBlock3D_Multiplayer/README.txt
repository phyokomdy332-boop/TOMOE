MiniBlock 3D Multiplayer
========================
Features:
- Player name
- 3D block world
- Touch joystick + look drag
- Place/break blocks
- Multiplayer over the same Wi‑Fi using a WebSocket server

APK:
This package is an Android WebView project. It needs Android Studio/Gradle with an Android SDK to compile the APK. The current environment cannot compile/sign an APK directly.

Server:
1. Install Node.js.
2. In server/, run: npm install
3. Run: node server.js
4. Find the host device's Wi‑Fi IP.
5. In the game, enter: ws://HOST_IP:8080
6. Friends on the same Wi‑Fi enter the same address.
