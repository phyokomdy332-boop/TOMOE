const WebSocket=require("ws"), http=require("http");
const port=8080; const clients=new Map();
let blocks=[]; for(let x=-8;x<=8;x++)for(let z=-8;z<=8;z++){blocks.push({x,y:0,z,t:"dirt"},{x,y:1,z,t:"grass"})}
const srv=http.createServer((req,res)=>{res.writeHead(200,{"Content-Type":"text/plain"});res.end("MiniBlock 3D server");});
const wss=new WebSocket.Server({server:srv});
wss.on("connection",ws=>{const id=Math.random().toString(36).slice(2);clients.set(ws,{id,name:"Player",x:0,y:2.5,z:7});
ws.send(JSON.stringify({type:"world",blocks}));
function broadcast(o){for(const c of clients.keys())if(c.readyState===1)c.send(JSON.stringify(o))}
ws.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch{return}let p=clients.get(ws);if(!p)return;
if(m.type==="join"){p.name=String(m.name||"Player").slice(0,16);ws.send(JSON.stringify({type:"players",id:p.id,players:[...clients.values()]}));broadcast({type:"players",id:p.id,players:[...clients.values()]})}
if(m.type==="move"){p.x=+m.x||0;p.y=+m.y||0;p.z=+m.z||0;p.name=String(m.name||p.name).slice(0,16);broadcast({type:"players",id:p.id,players:[...clients.values()]})}
if(m.type==="block"){blocks=blocks.filter(b=>!(b.x===m.x&&b.y===m.y&&b.z===m.z));if(m.t)blocks.push({x:m.x,y:m.y,z:m.z,t:m.t});broadcast({type:"block",x:m.x,y:m.y,z:m.z,t:m.t})}});
ws.on("close",()=>{clients.delete(ws);broadcast({type:"players",id,players:[...clients.values()]})});
});
srv.listen(port,"0.0.0.0",()=>console.log("MiniBlock server on port "+port));